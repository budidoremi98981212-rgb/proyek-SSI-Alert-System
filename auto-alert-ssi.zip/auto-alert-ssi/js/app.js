
// Auto-Alert SSI — Core Logic
(function(){
  const LS_KEY = 'ssi_logs_v1';
  const LS_SETTINGS = 'ssi_settings_v1';
  const LS_LANG = 'ssi_lang_v1';
  const LS_THEME = 'ssi_theme_v1';

  const i18n = {
    id: {
      title: 'Auto-Alert SSI',
      subtitle: 'Dashboard demo untuk memantau aktivitas kamar operasi & antibiotik profilaksis',
      theme: 'Tema', dark: 'Gelap', light:'Terang', language:'Bahasa',
      sim: 'Simulasi Personel', personIn: 'Personel Masuk', personOut: 'Personel Keluar',
      antibiotic: 'Antibiotik Profilaksis', givenAt: 'Waktu Pemberian', giveNow: 'Catat Pemberian',
      settings: 'Pengaturan', threshold: 'Ambang keterlambatan antibiotik (menit)', save: 'Simpan Pengaturan',
      log: 'Log Aktivitas', export: 'Ekspor CSV', import: 'Impor CSV',
      clear: 'Hapus Log', status: 'Status Sistem', ok: 'Aman', alert: 'Peringatan aktif',
      kpiIn:'Masuk', kpiOut:'Keluar', kpiAntibiotic:'Antibiotik terakhir', now:'Sekarang',
      disclaimer:'Demo non-medis. Jangan digunakan sebagai alat klinis.'
    },
    en: {
      title: 'Auto-Alert SSI',
      subtitle: 'Demo dashboard to monitor OR traffic & prophylactic antibiotic timing',
      theme: 'Theme', dark: 'Dark', light:'Light', language:'Language',
      sim: 'Personnel Simulation', personIn: 'Person In', personOut: 'Person Out',
      antibiotic: 'Prophylactic Antibiotic', givenAt: 'Admin Time', giveNow: 'Record Administration',
      settings: 'Settings', threshold: 'Antibiotic delay threshold (minutes)', save: 'Save Settings',
      log: 'Activity Log', export: 'Export CSV', import: 'Import CSV',
      clear: 'Clear Logs', status: 'System Status', ok: 'Safe', alert: 'Alert active',
      kpiIn:'Check-ins', kpiOut:'Check-outs', kpiAntibiotic:'Last antibiotic', now:'Now',
      disclaimer:'Demo only. Not for clinical use.'
    }
  };

  let lang = localStorage.getItem(LS_LANG) || 'id';
  let theme = localStorage.getItem(LS_THEME) || 'dark';
  let logs = JSON.parse(localStorage.getItem(LS_KEY) || '[]');
  let settings = JSON.parse(localStorage.getItem(LS_SETTINGS) || '{"threshold":60}');
  let lastAntibiotic = logs.filter(l=>l.event==='antibiotic_admin').slice(-1)[0]?.timestamp || null;

  const $ = sel => document.querySelector(sel);

  function t(key){ return i18n[lang][key] || key; }
  function fmt(ts){
    const d = new Date(ts);
    return d.toLocaleString(lang==='id'? 'id-ID':'en-US');
  }

  function renderTexts(){
    $('#title').textContent = t('title');
    $('#subtitle').textContent = t('subtitle');
    $('#label-theme').textContent = t('theme');
    $('#label-lang').textContent = t('language');
    $('#sim-title').textContent = t('sim');
    $('#btn-in').textContent = t('personIn');
    $('#btn-out').textContent = t('personOut');
    $('#antibiotic-title').textContent = t('antibiotic');
    $('#givenAtLabel').textContent = t('givenAt');
    $('#btn-give').textContent = t('giveNow');
    $('#settings-title').textContent = t('settings');
    $('#thresholdLabel').textContent = t('threshold');
    $('#btn-save-settings').textContent = t('save');
    $('#log-title').textContent = t('log');
    $('#btn-export').textContent = t('export');
    $('#btn-import').textContent = t('import');
    $('#btn-clear').textContent = t('clear');
    $('#status-title').textContent = t('status');
    $('#disclaimer').textContent = t('disclaimer');
    $('#kpi-in-label').textContent = t('kpiIn');
    $('#kpi-out-label').textContent = t('kpiOut');
    $('#kpi-abx-label').textContent = t('kpiAntibiotic');
  }

  function setTheme(name){
    theme = name; localStorage.setItem(LS_THEME, theme);
    const root = document.documentElement;
    root.classList.toggle('light', theme==='light');
    $('#opt-dark').checked = theme==='dark';
    $('#opt-light').checked = theme==='light';
  }

  function setLang(name){ lang = name; localStorage.setItem(LS_LANG, lang); renderTexts(); renderKPIs(); renderTable(); }

  function addLog(event, person, location, details){
    const item = {timestamp: new Date().toISOString(), event, person, location, details};
    logs.push(item);
    localStorage.setItem(LS_KEY, JSON.stringify(logs));
    if(event==='antibiotic_admin'){ lastAntibiotic = item.timestamp; }
    checkAlerts();
    renderKPIs();
    renderTable();
  }

  function checkAlerts(){
    let alertActive = false;
    // Rule 1: Antibiotic delay
    if(lastAntibiotic){
      const mins = (Date.now() - (new Date(lastAntibiotic)).getTime())/60000;
      if(mins > settings.threshold){ alertActive = true; }
    } else {
      // If no antibiotic recorded and time since start > threshold, alert
      alertActive = true;
    }
    $('#badge-status').className = 'badge ' + (alertActive? 'alert':'ok');
    $('#badge-status').textContent = alertActive ? t('alert') : t('ok');
    if(alertActive) beep();
  }

  function beep(){
    try{
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(880, ctx.currentTime);
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
      o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.3);
    }catch(e){ console.warn('Audio not supported'); }
  }

  function renderKPIs(){
    const inCount = logs.filter(l=>l.event==='person_in').length;
    const outCount = logs.filter(l=>l.event==='person_out').length;
    $('#kpi-in-val').textContent = inCount;
    $('#kpi-out-val').textContent = outCount;
    $('#kpi-abx-val').textContent = lastAntibiotic? fmt(lastAntibiotic) : (lang==='id'?'Belum ada':'None');
  }

  function renderTable(){
    const tbody = $('#log-tbody');
    tbody.innerHTML = logs.slice().reverse().map(l=>{
      return `<tr><td>${fmt(l.timestamp)}</td><td>${l.event}</td><td>${l.person||''}</td><td>${l.location||''}</td><td>${l.details||''}</td></tr>`;
    }).join('');
  }

  function exportCSV(){
    const header = 'timestamp,event,person,location,details\n';
    const rows = logs.map(l=>`${l.timestamp},${l.event},${(l.person||'').replace(/,/g,';')},${(l.location||'').replace(/,/g,';')},${(l.details||'').replace(/,/g,';')}`).join('\n');
    const blob = new Blob([header + rows], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'ssi_logs.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  function importCSV(file){
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result; const lines = text.split(/\r?\n/).filter(Boolean);
      const rows = lines.slice(1);
      rows.forEach(line=>{
        const [timestamp,event,person,location,details] = line.split(',');
        logs.push({timestamp,event,person,location,details});
      });
      localStorage.setItem(LS_KEY, JSON.stringify(logs));
      lastAntibiotic = logs.filter(l=>l.event==='antibiotic_admin').slice(-1)[0]?.timestamp || null;
      renderKPIs(); renderTable(); checkAlerts();
    };
    reader.readAsText(file);
  }

  function clearLogs(){ logs = []; localStorage.setItem(LS_KEY, JSON.stringify(logs)); lastAntibiotic = null; renderKPIs(); renderTable(); checkAlerts(); }

  function init(){
    // Theme
    setTheme(theme);
    document.getElementById('opt-dark').addEventListener('change', ()=> setTheme('dark'));
    document.getElementById('opt-light').addEventListener('change', ()=> setTheme('light'));
    // Language
    document.getElementById('opt-id').addEventListener('change', ()=> setLang('id'));
    document.getElementById('opt-en').addEventListener('change', ()=> setLang('en'));
    $('#opt-id').checked = lang==='id'; $('#opt-en').checked = lang==='en';

    // Buttons
    $('#btn-in').addEventListener('click', ()=> addLog('person_in','Anon','OK-1','Masuk/Check-in'));
    $('#btn-out').addEventListener('click', ()=> addLog('person_out','Anon','OK-1','Keluar/Check-out'));
    $('#btn-give').addEventListener('click', ()=> {
      const ts = new Date().toISOString();
      addLog('antibiotic_admin','Anon','OK-1','Prophylactic antibiotic');
    });

    // Settings
    $('#threshold').value = settings.threshold;
    $('#btn-save-settings').addEventListener('click', ()=>{
      const val = parseInt($('#threshold').value||'60',10);
      settings.threshold = isNaN(val)? 60 : Math.max(1, val);
      localStorage.setItem(LS_SETTINGS, JSON.stringify(settings));
      checkAlerts();
    });

    // Export/Import/Clear
    $('#btn-export').addEventListener('click', exportCSV);
    $('#file-import').addEventListener('change', (e)=> importCSV(e.target.files[0]));
    $('#btn-clear').addEventListener('click', clearLogs);

    renderTexts(); renderKPIs(); renderTable(); checkAlerts();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
