
# Auto-Alert SSI — Web Dashboard

> **Demo only — not for clinical use.**

Dashboard sederhana untuk memantau aktivitas keluar/masuk personel kamar operasi dan waktu pemberian antibiotik profilaksis, lengkap dengan **alert**, **ekspor CSV**, **dark/light toggle**, dan **bilingual UI (ID/EN)**.

## Fitur
- Simulasi personel masuk/keluar (log otomatis)
- Catat waktu pemberian antibiotik profilaksis
- Aturan alert berdasarkan ambang keterlambatan (default: 60 menit)
- Notifikasi audio (beep) saat alert aktif
- KPI ringkas: jumlah masuk, keluar, dan waktu antibiotik terakhir
- Ekspor ke CSV dan impor dari CSV
- Penyimpanan lokal (localStorage)
- Toggle tema (Dark/Light) dan bahasa (Indonesia/English)

## Struktur
```
auto-alert-ssi/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
├── assets/
│   ├── logo.png
│   └── favicon.png
├── data/
│   └── sample_logs.csv
└── README.md
```

## Menjalankan Secara Lokal
Cukup buka `index.html` di browser modern (Chrome/Edge/Firefox). Tidak perlu server.

## Deploy ke GitHub Pages
1. Buat repository baru di GitHub (misal: `auto-alert-ssi`).
2. Upload seluruh isi folder **auto-alert-ssi/** ke repository.
3. Masuk ke **Settings → Pages**.
4. Pada **Source**, pilih **Branch: main** dan **Folder: /** (root).
5. Klik **Save**. Dalam ±30 detik, situs akan aktif di:
   `https://USERNAME.github.io/auto-alert-ssi/`

## Catatan Penting
- Semua data disimpan di **localStorage** browser; untuk penggunaan tim/produksi, tambah backend/API.
- Aturan klinis di sini **hanya contoh**; sesuaikan kebijakan RS Anda.

## Lisensi
MIT
